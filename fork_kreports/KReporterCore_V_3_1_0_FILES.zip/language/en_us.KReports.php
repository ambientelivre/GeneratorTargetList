<?php 
$app_list_strings['moduleList']['KReports'] = 'KReports v3.0';

$app_list_strings['kreportstatus'] = array(
	'1' => 'draft',
	'2' => 'limited release',
	'3' => 'general release'
);

?>